from elasticsearch import (
    Elasticsearch,
    RequestsHttpConnection
)
from elasticsearch_dsl.query import (
    SpanNear,
    SpanTerm
)
import json
import boto3
from datetime import datetime
from requests_aws4auth import AWS4Auth

from elasticsearch_dsl import Integer, Float, connections, Document, Mapping, Percolator, Text, Date, Nested, Boolean, InnerDoc

region = 'eu-west-1'  # e.g. us-east-1
service = 'es'
credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key,
                   region, service, session_token=credentials.token)

# the Amazon ES domain, with https://
host = 'search-dubizzle-saved-search-es-fs3ixih452rurdiarz5gddq7f4.eu-west-1.es.amazonaws.com'
index_name = 'savedsearchindex1'
dtype = 'savedsearch'
url = 'https://' + host + '/' + index_name + '/' + dtype + '/'

headers = {"Content-Type": "application/json"}


def lambda_handler(event, context):
    es = Elasticsearch(
        hosts=[{'host': host, 'port': 443}],
        http_auth=awsauth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection
    )
    # print(es.info())

    # Read the json File
    # json_data = open('titles.json').read()
    # data = json.loads(json_data)

    # docs = data['response']['docs']

    # creating a new default elasticsearch connection
    # connections.configure(
    #     default={'hosts': 'localhost:9200'},
    # )
    connections.add_connection('default', es)

    class SavedSearch(InnerDoc):
        user_id = Integer()
        enabled = Boolean()
        query = Percolator()

    class DocumentToSave(Document):
        price = Float()
        description = Text()

        savedsearch = Nested(SavedSearch)

        class Index:
            name = index_name

        def save(self, ** kwargs):
            return super(DocumentToSave, self).save(** kwargs)

    # 1a. create the mappings in elasticsearch
    DocumentToSave.init()

    # 1b. or another alternative way of saving the mapping
    # query_mapping = Mapping('my-type')
    # query_mapping.field('title', 'text')
    # query_mapping.field('query', 'percolator')
    # query_mapping.save(index_name)

    # # 2a. index the query
    query = DocumentToSave(savedsearch={
        "user_id": 5,
        "enabled": "true",
        "query": {
            "bool": {
                "filter": [
                    {
                        "match": {
                            "description": {"query": "nintendo switch"}
                        }
                    },
                    {"range": {"price": {"lte": 300.00}}}
                ]
            }
        }
    })
    m = query.save()
    print(m)

    # 2b. or alternative index the query
    # for doc in docs:
    #     terms = doc['title'].split(" ")
    #     clauses = []
    #     for term in terms:
    #         field = SpanTerm(title=term)
    #         clauses.append(field)
    #     query = SpanNear(clauses=clauses)
    #     item = Document(query=query) < -- change this line
    #     item.save()

    # 3. send the percolate query
    # client = Elasticsearch()
    # response = es.search(
    #     index=index_name,
    #     body={
    #         "query": {
    #             "bool": {
    #                 "filter": [
    #                     {
    #                         "percolate": {
    #                             "field": "savedsearch.query",
    #                             "document": {
    #                                 "description": "Nintendo Switch",
    #                                 "price": 250.00
    #                             }
    #                         }
    #                     },
    #                     {"term": {"savedsearch.enabled": "true"}},
    #                     {"term": {"savedsearch.user_id": 5}}
    #                 ]
    #             }
    #         }
    #     }
    # )

    response = es.search(
        index=index_name,
        body={
            "query": {
                "match_all": {}
            }
        }
    )

    # response = es.indices.delete(
    #     index=index_name
    # )
    print(str(response) + ' records processed.')
    return str(response) + ' records processed.'
